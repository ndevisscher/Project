<!DOCTYPE html>
	<!--[if IE 8]>
		<html xmlns="http://www.w3.org/1999/xhtml" class="ie8" lang="nl-NL">
	<![endif]-->
	<!--[if !(IE 8) ]><!-->
		<html xmlns="http://www.w3.org/1999/xhtml" lang="nl-NL">
	<!--<![endif]-->
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Troonredes.nl &rsaquo; Inloggen</title>
	<link rel='stylesheet' id='buttons-css'  href='http://www.troonredes.nl/wp-includes/css/buttons.min.css?ver=4.2.4' type='text/css' media='all' />
<link rel='stylesheet' id='open-sans-css'  href='//fonts.googleapis.com/css?family=Open+Sans%3A300italic%2C400italic%2C600italic%2C300%2C400%2C600&#038;subset=latin%2Clatin-ext&#038;ver=4.2.4' type='text/css' media='all' />
<link rel='stylesheet' id='dashicons-css'  href='http://www.troonredes.nl/wp-includes/css/dashicons.min.css?ver=4.2.4' type='text/css' media='all' />
<link rel='stylesheet' id='login-css'  href='http://www.troonredes.nl/wp-admin/css/login.min.css?ver=4.2.4' type='text/css' media='all' />
<script type='text/javascript' src='http://www.troonredes.nl/wp-includes/js/jquery/jquery.js?ver=1.11.2'></script>
<script type='text/javascript' src='http://www.troonredes.nl/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.2.1'></script>
<meta name='robots' content='noindex,follow' />
	</head>
	<body class="login login-action-login wp-core-ui  locale-nl-nl">
	<div id="login">
		<h1><a href="https://nl.wordpress.org/" title="Mogelijk gemaakt door WordPress" tabindex="-1">Troonredes.nl</a></h1>
	
<form name="loginform" id="loginform" action="http://www.troonredes.nl/wp-login.php" method="post">
	<p>
		<label for="user_login">Gebruikersnaam<br />
		<input type="text" name="log" id="user_login" class="input" value="" size="20" /></label>
	</p>
	<p>
		<label for="user_pass">Wachtwoord<br />
		<input type="password" name="pwd" id="user_pass" class="input" value="" size="20" /></label>
	</p>
		<p class="forgetmenot"><label for="rememberme"><input name="rememberme" type="checkbox" id="rememberme" value="forever"  /> Gegevens onthouden</label></p>
	<p class="submit">
		<input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large" value="Inloggen" />
		<input type="hidden" name="redirect_to" value="http://www.troonredes.nl/wp-admin/" />
		<input type="hidden" name="testcookie" value="1" />
	</p>
</form>

<p id="nav">
	<a href="http://www.troonredes.nl/wp-login.php?action=lostpassword" title="Wachtwoord kwijt en gevonden">Wachtwoord vergeten?</a>
</p>

<script type="text/javascript">
function wp_attempt_focus(){
setTimeout( function(){ try{
d = document.getElementById('user_login');
d.focus();
d.select();
} catch(e){}
}, 200);
}

wp_attempt_focus();
if(typeof wpOnload=='function')wpOnload();
</script>

	<p id="backtoblog"><a href="http://www.troonredes.nl/" title="Ben je de weg kwijt?">&larr; Terug naar Troonredes.nl</a></p>
	
	</div>

	
	<link rel='stylesheet' id='shadowbox-css-css'  href='http://www.troonredes.nl/wp-content/uploads/shadowbox-js/src/shadowbox.css?ver=3.0.3' type='text/css' media='screen' />
<link rel='stylesheet' id='shadowbox-extras-css'  href='http://www.troonredes.nl/wp-content/plugins/shadowbox-js/css/extras.css?ver=3.0.3.10' type='text/css' media='screen' />
<script type='text/javascript' src='http://www.troonredes.nl/wp-content/uploads/shadowbox-js/4436d947743b4e124e3f2c68998dd9fb.js?ver=3.0.3'></script>
	<div class="clear"></div>
	</body>
	</html>
	